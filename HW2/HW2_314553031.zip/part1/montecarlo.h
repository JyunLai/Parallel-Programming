#ifndef MONTECARLO_H
#define MONTECARLO_H

long long count_in_circle_parallel(long long tosses);

#endif
